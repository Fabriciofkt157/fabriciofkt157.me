import { loadDb } from './state.js';
import { updateCodexTitle, buildNavMenu, renderContent } from './ui.js';
import { initializeEventHandlers } from './eventHandlers.js';

// Função principal que roda quando o DOM está pronto.
function main() {
    loadDb();
    updateCodexTitle();
    buildNavMenu();
    renderContent('home');
    initializeEventHandlers();
}

// Garante que o script só rode após o carregamento completo da página.
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', main);
} else {
    main();
}